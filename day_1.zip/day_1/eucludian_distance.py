import math

p1 = 2
p2 = 3
q1 = 10
q2 = 8

result = math.sqrt(((p1 - q1) ** 2) + ((p2 - q2) ** 2))

print(result)
