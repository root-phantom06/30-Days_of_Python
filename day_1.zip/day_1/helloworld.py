# Question 1
print("python3 --version")

# Question 2
print(4 + 3)  # addition(+)
print(4 - 3)  # substraction(-)
print(4 * 3)  # multiplication(*)
print(4 % 3)  # modulus(%)
print(4 / 3)  # division(/)
print(4**3)  # exponential(**)
print(4 // 3)  # floor division(//)

# Question 3
print("Mike")
print("GBELEOU")
print("Togo")
print("I am enjoying 30 days of python")

# Question 4
print(type(10))
print(type(9.8))
print(type(3.14))
print(type(4 - 4j))
print(type(["Asabeneh", "Python", "Finland"]))
print(type("Mike"))
print(type("GBELEOU"))
print(type("Togo"))
