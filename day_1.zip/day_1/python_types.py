# Number types
integer_number = 6
float_number = 3.14
complex_number = 4 - 4j

# String type
text = "I love 30 days of python"

# Boolean type
is_active = True

# List type
foods = ["Ayimolou", "Com", "Akoume"]

# Tupple type
coordinates = (10.0, 20.0)

# Set type
uniq_numbers = {1, 2, 3, 2}

# Dictionary type
Person = {"name": "Mike", "age": 30, "city": "Torronto"}
